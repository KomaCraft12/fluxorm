console.log("QUERYBUILDER INDEX:", __filename);

module.exports = {
    QueryBuilder: require("./src/QueryBuilder"),
    Model: require("./src/Model"),

    relations: require("./src/relations"),
    db: require("./src/database/connection"),

    utils: require("./src/utils/helpers"),
    Validator: require("./src/utils/Validator"),

    Router: require("./src/server/Router"),
    Server: require("./src/server/Server")
};
