const User = require(process.cwd() + "/models/User");

module.exports = {

    // ------------------------------------------------------------------------------------------------
    // TOKEN alapú auth (Authorization: Bearer TOKEN)
    // ------------------------------------------------------------------------------------------------
    authToken: async (req, res, next) => {
        try {
            const header = req.headers.authorization;

            if (!header || !header.startsWith("Bearer ")) {
                return res.status(401).json({ message: "Missing or invalid token" });
            }

            const token = header.split(" ")[1];

            const user = await User.where("api_token", token).first();

            if (!user) {
                return res.status(401).json({ message: "Invalid token" });
            }

            req.user = user; // rögzítjük a bejelentkezett user-t
            next();
        }
        catch (err) {
            console.error("authToken error:", err);
            res.status(500).json({ message: "Auth server error" });
        }
    },

    // ------------------------------------------------------------------------------------------------
    // COOKIE alapú auth (Cookie: auth_token=xxxxx)
    // ------------------------------------------------------------------------------------------------
    authCookie: async (req, res, next) => {
        try {
            const token = req.cookies?.auth_token;

            if (!token) {
                return res.status(401).json({ message: "Missing auth cookie" });
            }

            const user = await User.where("api_token", token).first();

            if (!user) {
                return res.status(401).json({ message: "Invalid auth cookie" });
            }

            req.user = user;
            next();
        }
        catch (err) {
            console.error("authCookie error:", err);
            res.status(500).json({ message: "Auth server error" });
        }
    }

};