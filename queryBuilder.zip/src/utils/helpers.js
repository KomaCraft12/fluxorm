module.exports = {
    // későbbi funkciók helye
};
